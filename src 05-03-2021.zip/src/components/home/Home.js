import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import imgNew from '../home/Fresher.jpg'
import exp from '../home/prof.jpg'
import { Button } from '@material-ui/core';
import Container from '@material-ui/core/Container';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Link,
  Redirect,
  NavLink
} from "react-router-dom";
import { useHistory } from "react-router";


const useStyles = makeStyles((theme) => ({

  root: {
    display: 'flex',
    justifyContent:'center',
    '& > *': {
      margin: theme.spacing(20),
      width: theme.spacing(16),
      height: theme.spacing(16),
    },
  },
}));

export default function Home() {
  const classes = useStyles();
  const history = useHistory();
  
  const  handleClick = () =>{
    
        history.push({
          pathname:  "/fresher"
        })
        
       }
       const  handleClickProf = () =>{
    
        history.push({
          pathname:  "/prof"
        })
         
      }
   
  return (
    
    <Router> 
    <div className={classes.body}>
    <div>
    <h1 style={{display:'flex', justifyContent:'center'}}>Tell us About yourself</h1>
    <div className={classes.root}>
      <div style={{marginTop:'100px'}}>
      <img src={imgNew} style={{width:'190%', height:'170%', marginLeft:'-60px',marginTop:'-50px'}} alt='Logo'/> 
      <Button onClick={handleClick} style={{ backgroundColor: "#23cc7c", color:'white',marginTop:'30px', marginLeft:'-60px', width:'250px', height:"50px"}} ><strong>I am a Fresher</strong></Button>
      </div>
      <div style={{marginTop:'100px'}}>
      <img src={exp} style={{width:'200%', height:'170%',marginTop:'-50px'}} alt='Logo'/>
   
    <Button onClick={handleClickProf} style={{ backgroundColor: "#23cc7c", color:'white',marginTop:'30px', marginLeft:'10px', width:'250px', height:"50px"}} disableElevation><b>I am a Professional</b></Button>
     
    </div>
    </div>
    </div>
    </div>
    </Router> 
  );
}