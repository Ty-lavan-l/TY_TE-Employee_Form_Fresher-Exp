import React from 'react'
import Home from './Home';
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Link,
    NavLink
  } from "react-router-dom";
import StepForm from '../fresher/StepForm'
import ProfForm from '../professional/StepForm';

export default function Routing() {
    
    return (
        <div>
            <Router>
            <Switch>
                <Route exact path="/">
                <Home />
                </Route>
                
                <Route exact path="/fresher">
                <StepForm/>
                </Route>
            
                <Route exact path="/prof">
                <ProfForm/>
                </Route>
            
            
            </Switch>



            </Router>
        </div>
    )
}
