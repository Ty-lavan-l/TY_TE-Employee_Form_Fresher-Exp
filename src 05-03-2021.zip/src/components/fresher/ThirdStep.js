import React, { useState } from "react"
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Rating from "@material-ui/lab/Rating";
import { makeStyles } from "@material-ui/core/styles";
import TabsComThree from './tabs/TabsComThree'

import { Button, Grid, IconButton } from '@material-ui/core';


const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export default function ThirdStep({ handleNext, handleBack, values: { courses, qualification, yop, InstitutionName }, formErrors }) {
const [value, setValue] = React.useState();
const useStyles = makeStyles((theme) => ({
    root: {
      display: "flex-end",
      marginLeft: "200px",
      flexDirection: "column",
      "& > * + *": {
        marginTop: theme.spacing(1)
      }
    }
  }));
  const classes = useStyles();
  
  return (
    <div >
           <TabsComThree/>

      <Grid container spacing={2} alignItems="center"  style={{marginTop:"50px"}}>
       <Grid xs={3}>
         </Grid>
         <Grid item xs={6}>
    <Autocomplete
      multiple
      id="checkboxes-tags-demo"
      options={skillsonfrontend}
      disableCloseOnSelect
      getOptionLabel={(option) => option.title}
      renderOption={(option, { selected }) => (
        <React.Fragment>
          <Checkbox
            icon={icon}
            color='primary'
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
           
          />
          {option.title}
          <div style={{ right:'2'}}>
     <Rating
          name="simple-controlled"
          value={value}
          onChange={(event, newValue) => {
            setValue(newValue);
          }}
        />
          </div>

        </React.Fragment>
      )}
      style={{ width: 700  }}
      renderInput={(params) => (
        <TextField {...params} variant="outlined" label="Skills on Frontend" placeholder="Skills on Frontends" />
      )}
    />
    <br></br>
    
    <Autocomplete
      multiple
      id="checkboxes-tags-demo"
      options={skillsonbackend}
      disableCloseOnSelect
      getOptionLabel={(option) => option.title}
      renderOption={(option, { selected }) => (
        
        <React.Fragment style={{display:'flex', justifyContent:'center'}}>

          <Checkbox
            icon={icon}
            color='primary'
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
          />
          {option.title}


      <Rating name="size-small" size="small" />


        </React.Fragment>
      )}
      style={{ width: 700  }}
      renderInput={(params) => (
        <TextField {...params} variant="outlined" label="Skills on Backend" placeholder="Skills on Backend" />
      )}
    />

    <br></br>
<Autocomplete
      multiple
      id="checkboxes-tags-demo"
      options={database}
      disableCloseOnSelect
      getOptionLabel={(option) => option.title}
      renderOption={(option, { selected }) => (
        <React.Fragment>
          <Checkbox
            icon={icon}
            color='primary'
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
          />
          {option.title}



          <div >
      <Rating name="size-small" size="small" />
    </div>
        </React.Fragment>
      )}
      style={{ width: 700  }}
      renderInput={(params) => (
        <TextField {...params} variant="outlined" label="Database Used" placeholder="Database Used" />
      )}
    />

    <br></br>
<Autocomplete
      multiple
      id="checkboxes-tags-demo"
      options={tools}
      disableCloseOnSelect
      getOptionLabel={(option) => option.title}
      renderOption={(option, { selected }) => (
        <React.Fragment>
          <Checkbox
            icon={icon}
            color='primary'
            checkedIcon={checkedIcon}
            style={{ marginRight: 8 }}
            checked={selected}
          />
          {option.title}



          <div >
      <Rating name="size-small" size="small"/>
    </div>
        </React.Fragment>
      )}
      style={{ width: 700  }}
      renderInput={(params) => (
        <TextField {...params} variant="outlined" label="Development Tools & Technologies" placeholder="Development Tools & Technologies" />
      )}
    />
 <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
         <Button variant="contained" color="default"  onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}}  >
         {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
       <Button variant="contained"  onClick={  handleNext } style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"200px"}}  >
       {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
      </div>
      </Grid>

      </Grid>
    </div>
  );
}

// Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
const skillsonfrontend = [
  { title: 'Html' },
  { title: 'Css' },
  { title: 'javascript' },
  { title: 'Jquery'  },
  { title: 'Bootstrap'  },
  { title: "React Js"},
  { title: 'Angular'},
  { title: 'Vue Js'},
 
];
const tools= [
  { title: 'Eclipse IDE' },
  { title: 'vsCode' },
  { title: 'MySql' },
  { title: 'Jira'  },
  { title: 'GitHub'  },
  { title: "Jenkins"},
  { title: 'Fiddler'},
  { title: 'Netbeans'},
  
];


const skillsonbackend = [
  { title: 'Java' },
  { title: 'JavaScript' },
  { title: 'J2EE' },
  { title: 'SQL'},
  { title: 'Spring'},
  { title: 'Spring Boot'},
  { title: 'Spring Core'},
  { title: 'MongoDB'},
  { title: 'Postgresql'},
  { title: "Ruby"},
  
];
const database= [
  { title: 'MySql' },
  { title: 'Jira'  },
  { title: 'Mango DB'  },
  { title: "Jenkins"},
  { title: 'Fiddler'},
  { title: 'Netbeans'},
  
];
