import React, { Fragment, useState } from "react"
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Grid from "@material-ui/core/Grid"
import TextField from "@material-ui/core/TextField"
import Button from "@material-ui/core/Button"
import {RoundedCornerOutlined } from "@material-ui/icons"
import Checkbox from '@material-ui/core/Checkbox';
import TabsCom from "./tabs/TabsCom";
import FormControl from "@material-ui/core/FormControl"
import RadioGroup from "@material-ui/core/RadioGroup";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import Radio from "@material-ui/core/Radio";
import CloudUpload from '@material-ui/icons/CloudUpload';
import { Container, FormLabel } from "@material-ui/core";
import Select from "@material-ui/core/Select"
import InputLabel from "@material-ui/core/InputLabel"
import MenuItem from "@material-ui/core/MenuItem"


function StyledRadio(props) {
  const classes = useStyles();

  return (
    <Radio
      className={classes.root}
      disableRipple
      color="default"
      checkedIcon={<span className={clsx(classes.icon, classes.checkedIcon)} />}
      icon={<span className={classes.icon} />}
      {...props}
    />
  );
}

const useStyles = makeStyles({
  root: {
    "&:hover": {
      backgroundColor: "transparent"
    }
  },
  icon: {
    borderRadius: "50%",
    width: 16,
    height: 16,
    boxShadow:
      "inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)",
    backgroundColor: "#f5f8fa",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))",
    "$root.Mui-focusVisible &": {
      outline: "2px auto rgba(19,124,189,.6)",
      outlineOffset: 2
    },
    "input:hover ~ &": {
      backgroundColor: "#ebf1f5"
    },
    "input:disabled ~ &": {
      boxShadow: "none",
      background: "rgba(206,217,224,.5)"
    }
  },
  checkedIcon: {
    backgroundColor: "#137cbd",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))",
    "&:before": {
      display: "block",
      width: 16,
      height: 16,
      backgroundImage: "radial-gradient(#fff,#fff 28%,transparent 32%)",
      content: '""'
    },
    "input:hover ~ &": {
      backgroundColor: "#106ba3"
    },
    input: {
      display: "none"
    }
  }
});

// Destructuring props
const FirstStep = ({ handleNext, handleChange, values: { emplopyeeId,fullName, doj,contact,xyz, gender,alternateContact,emergencyContactOne,emergencyContactTwo,offEmail,personalEmail,permanentAddress,temporaryAddress}, formErrors }) => {
  // Check if all values are not empty or if there are some error

  //validation
  const isValid =
  emplopyeeId.length > 0 &&
  !formErrors.emplopyeeId &&
  fullName.length > 0 &&
  !formErrors.fullName  &&
  doj.length > 0 &&
  !formErrors.doj &&
  contact.length > 0 &&
  !formErrors.contact 
  && alternateContact.length > 0 &&
  !formErrors.alternateContact
   && emergencyContactOne.length > 0 &&
  !formErrors.emergencyContactOne
   && emergencyContactTwo.length > 0 &&
  !formErrors.emergencyContactTwo
   && offEmail.length > 0 &&
  !formErrors.offEmail
   && personalEmail.length > 0 &&
  !formErrors.personalEmail
   && permanentAddress.length > 0 &&
  !formErrors.permanentAddress 
  &&
  temporaryAddress.length > 0 && 
  !formErrors.temporaryAddress
  

  const classes = useStyles();

  return (
    <Fragment>
            <TabsCom/>
<br></br>
      <Container maxWidth="md">
      <Grid container spacing={2} alignItems="center" noValidate>
        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Employee ID"
            name="emplopyeeId"
            placeholder="Your employee id"
            margin="normal"
            value={emplopyeeId || ""}
            onChange={handleChange}
            error={!!formErrors.emplopyeeId}
            helperText={formErrors.emplopyeeId}
            required
            variant="outlined"
          />
        </Grid>






        <Grid item xs={12} sm={6}>
<FormControl component="fieldset">
  <FormLabel component="legend">Gender</FormLabel>
  <RadioGroup value={gender}  onChange={handleChange} aria-label="gender" name="gender" row>
    <FormControlLabel value={"female"}  control={<StyledRadio />} label="Female" />
    <FormControlLabel value={"male"} control={<StyledRadio />} label="Male" />
    <FormControlLabel value={"other"} control={<StyledRadio />} label="Other" />

  </RadioGroup>
</FormControl>
</Grid>








        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            label="Name"
            name="fullName"
            type="text"
            placeholder="Your name"
            margin="normal"
            value={fullName || ""}
            onChange={handleChange}
            error={!!formErrors.fullName}
            helperText={formErrors.fullName}
            required
            variant="outlined"
          />
        </Grid>

        <Grid item xs={12} sm={6}>
          <TextField
            fullWidth
            InputLabelProps={{
              shrink: true
            }}
            label="TY Joining Date"
            name="doj"
            type="date"
            value={doj || ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.doj}
            helperText={formErrors.doj}
            required
            variant="outlined"
          />
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Contact Number"
            name="contact"
            placeholder="i.e: xxx-xxx-xxxx"
            type="phone"
            value={contact || ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.contact}
            helperText={formErrors.contact}
            required
            variant="outlined"
          />
        
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Alternate Number"
            name="alternateContact"
            placeholder="i.e: xxx-xxx-xxxx"
            type="phone"
            value={alternateContact || ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.alternateContact}
            helperText={formErrors.alternateContact}
            required
            variant="outlined"
          />
        
        </Grid>

        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Emergency Contact Number1"
            name="emergencyContactOne"
            placeholder="i.e: xxx-xxx-xxxx"
            type="phone"
            value={emergencyContactOne|| ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.emergencyContactOne}
            helperText={formErrors.emergencyContactOne}
            required
            variant="outlined"
          />
        
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Emergency Contact Number2"
            name="emergencyContactTwo"
            placeholder="i.e: xxx-xxx-xxxx"
            type="phone"
            value={emergencyContactTwo|| ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.emergencyContactTwo}
            helperText={formErrors.emergencyContactTwo}
            required
            variant="outlined"
          />
        
        </Grid>

        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Office Mail ID"
            name="offEmail"
            placeholder="Your office mail id"
            type="email"
            value={offEmail || ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.offEmail}
            helperText={formErrors.offEmail}
            required
            variant="outlined"
          />
        
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
            fullWidth
            label="Personal Mail ID"
            name="personalEmail"
            placeholder="Your personal mail id"
            type="email"
            value={personalEmail || ""}
            onChange={handleChange}
            margin="normal"
            error={!!formErrors.personalEmail}
            helperText={formErrors.personalEmail}
            required
            variant="outlined"
          />
        
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
         fullWidth
         label="Permanent Address"
         name="permanentAddress"
         placeholder="Your permanent address"
         type="add"
         value={permanentAddress || ""}
         onChange={handleChange}
         margin="normal"
         error={!!formErrors.permanentAddress}
         helperText={formErrors.permanentAddress}
         required
        multiline
        rows={2}
        rowsMax={4}
        variant="outlined"
        />
        </Grid>
        <Grid item xs={12} sm={6}>
        <TextField
         fullWidth
         label="Temporary Address"
         name="temporaryAddress"
         placeholder="Your temporary address"
         type="add"
         value={temporaryAddress || ""}
         onChange={handleChange}
         margin="normal"
         error={!!formErrors.temporaryAddress}
         helperText={formErrors.temporaryAddress}
         required
        multiline
        rows={2}
        rowsMax={4}
        variant="outlined"
        />
        </Grid>
 
      </Grid>
      <input style={{display:"none"}}
        accept=".pdf,.csv"
        className={classes.input}
        id="contained-button-file"
        multiple
        type="file"
      />
      <label htmlFor="contained-button-file">
        <Button variant="contained"  component="span" style={{ backgroundColor: "#0b1029", color: "white", border: "RoundedCornerOutlined"}}>
          Resume &emsp;
          <CloudUpload/>
        </Button>
      </label>
      <br/>
      <FormControlLabel
        control={<Checkbox name="checkedA" color="default" />}
        label="I agree to all terms and conditions"
      />
      <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
        <Button variant="contained" disabled={!isValid}  onClick={isValid ? handleNext : null}  style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}}>
          Next
        </Button>
      </div>
      </Container>
    </Fragment>
  )
}

export default FirstStep