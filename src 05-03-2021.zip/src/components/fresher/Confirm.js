import React, { Fragment } from "react"
import List from "@material-ui/core/List"
import ListItem from "@material-ui/core/ListItem"
import ListItemText from "@material-ui/core/ListItemText"
import Divider from "@material-ui/core/Divider"
import Button from "@material-ui/core/Button"

// Destructure props
const Confirm = ({ handleNext, handleBack, values }) => {
  const {emplopyeeId,fullName,contact,doj,emergencyContactOne,emergencyContactTwo,alternateContact,
  offEmail,personalEmail,gender,permanentAddress,higestqualification,
  temporaryAddress,collegename,course,universityname,pname,techused,
  psummary,rolesandresp,
  resume,
  highestQualification,
  specification,
  institutionName,yop, percentage, skillsFrontEnd,skillsBackEnd,dataBase,delevepomentTools,
  projectName,
  technologyUsed,
  projectSummary,
  roleAndsResponsibility,
 } = values



  return (
    <Fragment>
      <List disablePadding>
        <div style={{display:'flex', justifyContent:"space-around"}}>
        <div>

        <ListItem>
          <ListItemText primary="Full Name" secondary={fullName} />
        </ListItem>
        <ListItem>
          <ListItemText primary="Employee Id" secondary={emplopyeeId} />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Temporary Address" secondary={temporaryAddress} />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Official Email " secondary={offEmail} />
        </ListItem>
        <Divider />
        
        <ListItem>
          <ListItemText primary="Personal Email " secondary={personalEmail} />
        </ListItem>
        <Divider />

        <ListItem>
          <ListItemText primary="Gender" secondary={gender} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="Date of Joining" secondary={doj} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="Permanent Address" secondary={permanentAddress} />
        </ListItem>

        <Divider />
          
        </div>

        {/* ************************************** */}

          <div>
        <ListItem>
          <ListItemText primary="Contact" secondary={contact.length > 0 ? contact : "Not Provided"} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="College Name" secondary={collegename} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="University Name" secondary={universityname} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary=" Your course" secondary={course} />
        </ListItem>

        <Divider />


        <ListItem>
          <ListItemText primary="Project Name" secondary={pname} />
        </ListItem>
        <Divider />


        <ListItem>
          <ListItemText primary="Technology Used" secondary={techused} />
        </ListItem>
        <Divider />


        <ListItem>
          <ListItemText primary="Project Summary" secondary={psummary} />
        </ListItem>

        <Divider />


        <ListItem>
          <ListItemText primary="Roles & Responsibility" secondary={rolesandresp} />
        </ListItem>
        <Divider />


        <ListItem>
          <ListItemText primary="College Name" secondary={collegename} />
        </ListItem>
        <Divider />


        </div>

        </div>
      </List>
      <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
            <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
              {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
            <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
              {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
          </div>
    </Fragment>
  )
}

export default Confirm