// import React, { useState } from 'react';
// import Container from '@material-ui/core/Container';
// import TextField from '@material-ui/core/TextField';
// import Button from '@material-ui/core/Button';
// import IconButton from '@material-ui/core/IconButton';
// import RemoveIcon from '@material-ui/icons/Remove';
// import AddIcon from '@material-ui/icons/Add';
// import Icon from '@material-ui/core/Icon';
// import { v4 as uuidv4 } from 'uuid';
// import { makeStyles } from '@material-ui/core/styles';
// import Autocomplete from '@material-ui/lab/Autocomplete';
// import Grid from "@material-ui/core/Grid"
// import TabsCompSec from './tabs/TabsCompSec'
// import TabsComSec from './tabs/TabsCompSec';

// const useStyles = makeStyles((theme) => ({
//   formControl: {
//     margin: theme.spacing(1),
//     minWidth: 120,
//   },
//   selectEmpty: {
//     marginTop: theme.spacing(2),
//   },
//   root: {
//     '& .MuiTextField-root': {
//       margin: theme.spacing(1),
//     },
//   },
//   button: {
//     margin: theme.spacing(1),
//   }
// }));

// const SecondStep = ({handleNext, handleBack, handleChange, values: { xyz,emplopyeeId, collegename,contact,gender,alternateContact,emergencyContactOne,emergencyContactTwo,offEmail,personalEmail,permanentAddress,temporaryAddress}}) => {
//   const classes = useStyles()
//   const [inputFields, setInputFields] = useState([
//     { id: uuidv4(), courses: '', qualification: '', InstitutionName: '', years: '' },
//   ]);
//   const [state, setState] = React.useState({
//     courses: '',
//     name: 'hai',
//     qualification: '',
//     yop: '',
//     InstitutionName: '',
//   });
//   const handleChange1 = (event) => {
//     const name = event.target.name;
//     setState({
//       ...state,
//       [name]: event.target.value,
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log("InputFields", inputFields);
//   };

//   const handleChangeInput = (id, event) => {
//     const newInputFields = inputFields.map(i => {
//       if (id === i.id) {
//         i[event.target.name] = event.target.value
//       }
//       return i;
//     })

//     setInputFields(newInputFields);
//   }

//   const handleAddFields = () => {
//     setInputFields([...inputFields, { id: uuidv4(), courses: '', qualification: '', InstitutionName: '', years: '' }])
//   }

//   const handleRemoveFields = id => {
//     const values = [...inputFields];
//     values.splice(values.findIndex(value => value.id === id), 1);
//     setInputFields(values);
//   }
//   return (

//     <div>
//       <TabsComSec/>
//       <Grid container spacing={2} alignItems="center" >
//         <Grid xs={3}>
//         </Grid>
//         <Grid item xs={6} 
//         style={{marginTop:"50px"}}>
//           <form className={classes.root} onSubmit={handleChange}>
//             {inputFields.map(inputField => (
//               <div key={inputField.id}>
//                 <Autocomplete
//                   name="xyz"
//                   value={xyz || ""}
//                   options={quali.map((option) => option.title)}
//                   renderInput={(params) => (
//                     <TextField {...params} label="Select your Highest Qualification" margin="normal" variant="outlined" />
//                   )}
//                   onChange={event => handleChangeInput(inputField.id, event)}
//                 />
//                 <Autocomplete
//                   name="courses"
//                   freeSolo
//                   options={cour.map((option) => option.title)}
//                   renderInput={(params) => (
//                     <TextField {...params} label="Select your courses" margin="normal" variant="outlined" />
//                   )}
//                   value={inputField.qualification}
//                   onChange={event => handleChangeInput(inputField.id, event)}
//                 />
//                 <Grid item xs={12} fullWidth>
//                   <TextField
//                     fullWidth
//                     label="InstitutionName"
//                     name="collegename"
//                     placeholder="InstitutionName"
//                     margin="normal"
//                     value={collegename}
//                     onChange={handleChange1}
//                     //  helperText={InstitutionName}
//                     // value={inputField.InstitutionName}
//                     // onChange={event => handleChangeInput(inputField.id, event)}
//                     variant="outlined"
//                   />
//                 </Grid>
//                 <Autocomplete
//                   name="years"
//                   freeSolo
//                   options={years.map((option) => option.title)}
//                   renderInput={(params) => (
//                     <TextField {...params} label="Year of Passout" margin="normal" variant="outlined" />
//                   )}
//                   value={inputField.qualification}
//                   onChange={event => handleChangeInput(inputField.id, event)}
//                 />
//                 <div style={{display:"flex",justifyContent:"flex-end"}}>
//                 <IconButton disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>
//                   <RemoveIcon />
//                 </IconButton>
//                 <IconButton
//                   onClick={handleAddFields}
//                 >
//                   <AddIcon />
//                 </IconButton>
//                 </div>
//               </div>
//             ))}
//           </form>
//           <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
//             <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
//               {/* onClick={handleBack} style={{ marginRight: 10 }} */}
//           Back
//         </Button>
//             <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
//               {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
//          Next
//       </Button>
//           </div>
//         </Grid>
//       </Grid>
//     </div>
//   );
// }
// const quali = [
//   { title: 'BE' },
//   { title: 'BTech' },
//   { title: 'MBA' },
//   { title: 'BCA' },
//   { title: 'MTech' },
//   { title: "MCA" },
//   { title: "BSC" },
// ];
// const cour = [
//   { title: 'Computer Science' },
//   { title: 'Electronics and communication' },
//   { title: 'Mechanical and Engineering' },
//   { title: 'Civil Engineering' },
//   { title: 'Bio-Medical Engineering' },
//   { title: "Electronics and Instrumentation" },
// ];
// const years = [
//   { title: '2013' },
//   { title: '2014' },
//   { title: '2015' },
//   { title: '2016' },
//   { title: '2017' },
//   { title: '2018' },
//   { title: '2019' },
//   { title: '2020' },
//   { title: '2021' },
// ];


// export default SecondStep;


import React, { Fragment } from "react"
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Grid from "@material-ui/core/Grid"
import TextField from "@material-ui/core/TextField"
import Button from "@material-ui/core/Button"
import Checkbox from '@material-ui/core/Checkbox';
import FormControl from "@material-ui/core/FormControl"
import RadioGroup from "@material-ui/core/RadioGroup";
import clsx from "clsx";
import { makeStyles } from "@material-ui/core/styles";
import Radio from "@material-ui/core/Radio";
import CloudUpload from '@material-ui/icons/CloudUpload';
import { Container, FormLabel, InputLabel, MenuItem, Select } from "@material-ui/core";
import TabsComSec from './tabs/TabsCompSec';
import Autocomplete from '@material-ui/lab/Autocomplete';





const useStyles = makeStyles({
  root: {
    "&:hover": {
      backgroundColor: "transparent"
    }
  },
  icon: {
    borderRadius: "50%",
    width: 16,
    height: 16,
    boxShadow:
      "inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)",
    backgroundColor: "#f5f8fa",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))",
    "$root.Mui-focusVisible &": {
      outline: "2px auto rgba(19,124,189,.6)",
      outlineOffset: 2
    },
    "input:hover ~ &": {
      backgroundColor: "#ebf1f5"
    },
    "input:disabled ~ &": {
      boxShadow: "none",
      background: "rgba(206,217,224,.5)"
    }
  },
  checkedIcon: {
    backgroundColor: "#137cbd",
    backgroundImage:
      "linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))",
    "&:before": {
      display: "block",
      width: 16,
      height: 16,
      backgroundImage: "radial-gradient(#fff,#fff 28%,transparent 32%)",
      content: '""'
    },
    "input:hover ~ &": {
      backgroundColor: "#106ba3"
    },
    input: {
      display: "none"
    }
  }
});




const SecondStep = ({ handleNext, handleChange, handleBack, values: { collegename,universityname, course, gender,alternateContact,emergencyContactOne,emergencyContactTwo,offEmail,personalEmail,permanentAddress,temporaryAddress}, formErrors }) => {

  const classes = useStyles();

  

  return (
    <Fragment>
            <TabsComSec/>
<br></br>
      <Container maxWidth="md">
      <Grid container spacing={2} alignItems="center" noValidate>
{/* *************************************** */}


        <TextField
            fullWidth
            label="College Name"
            name="collegename"
            type="text"
            placeholder="College Name"
            margin="normal"
            value={collegename || ""}
            onChange={handleChange}
            error={!!formErrors.collegename}
            helperText={formErrors.collegename}
            required
            variant="outlined"
          />

          <TextField
            fullWidth
            label="University Name"
            name="universityname"
            type="text"
            placeholder="College Name"
            margin="normal"
            value={universityname || ""}
            onChange={handleChange}
            error={!!formErrors.universityname}
            helperText={formErrors.universityname}
            required
            variant="outlined"
          />


<h1>* Some fields goes here *</h1> 


{/* <FormControl variant="outlined" className={classes.formControl}>
        <InputLabel id="demo-simple-select-outlined-label">course</InputLabel>
        <Select
          
          labelId="demo-simple-select-outlined-label"
          id="demo-simple-select-outlined"
          value={course || ""}
          type="text"
          onChange={handleChange}
          label="course"
        >
          <MenuItem value={course || ""}>
          </MenuItem>
          <MenuItem value={"10"}>Ten</MenuItem>
          <MenuItem value={"20"}>Twenty</MenuItem>
          <MenuItem value={"30"}>Thirty</MenuItem>
        </Select>
      </FormControl> */}

 
      </Grid>
      <input style={{display:"none"}}
        accept=".pdf,.csv"
        className={classes.input}
        id="contained-button-file"
        multiple
        type="file"
      />
      <br/>
                <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
            <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
              {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
            <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
              {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
          </div>
      </Container>
    </Fragment>
  )
}


const cour = [
  { title: 'Computer Science' },
  { title: 'Electronics and communication' },
  { title: 'Mechanical and Engineering' },
  { title: 'Civil Engineering' },
  { title: 'Bio-Medical Engineering' },
  { title: "Electronics and Instrumentation" },
];

export default SecondStep