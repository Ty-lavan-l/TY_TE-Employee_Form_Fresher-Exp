import React, { useState } from "react"
import Box from "@material-ui/core/Box"
import Typography from "@material-ui/core/Typography"
import Confirm from './Confirm'
import Success from './Success'

import formValidation from '../fresher/Helper/formValidation'
import FirstStep from './FirstStep'
import SecondStep from './SecondStep'
import ThirdStep from './ThirdStep'
import FourthStep from './FourthStep'
import FifthStep from './FifthStep'


// Step titles
const labels = ["First Step", "Second Step", "Third Step","FourthStep","FifthStep","Confirmation"]

const initialValues = {
  emplopyeeId:"",
  fullName: "",
  contact: "",
  doj:"",
  emergencyContactOne:"",
  emergencyContactTwo:"",
  alternateContact:"",
  offEmail: "",
  personalEmail: "",
  gender: "",
  // city: "",
  permanentAddress:"",
  temporaryAddress:"",
  resume:"",
  highestQualification:"",
  specification:"",
  institutionName:"",
  yop:"",
  percentage:"",
  skillsFrontEnd:"",
  skillsBackEnd:"",
  dataBase:"",
  delevepomentTools:"",
  projectName:"",
  technologyUsed:"",
  projectSummary:"",
  roleAndsResponsibility:"",

}

const fieldsValidation = {
  fullName: {
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
    
  },
  offEmail: {
    error: "",
    validate: "email"
  },
  personalEmail: {
    error: "",
    validate: "email"
  },
  gender: {},
  doj: {},
  city: {
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
  },
  emplopyeeId:{
    error: "",
    validate: "number",
    minLength: 3,
    maxLength: 20
  },
  emergencyContactOne:{
    error: "",
    validate: "phone",
    minLength: 10,
    maxLength: 13
  },
  emergencyContactTwo:{
    error: "",
    validate: "phone",
    minLength: 10,
    maxLength: 13
  },
  alternateContact:{
    error: "",
    validate: "phone",
    minLength: 10,
    maxLength: 13

  },
  permanentAddress:{
    error: "",
    validate: "add",
    minLength: 3,
    maxLength: 200
  },
  temporaryAddress:{
    error: "",
    validate: "add",
    minLength: 3,
    maxLength: 200
  },
  highestQualification:{
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
  },
  specification:{
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
  },
  institutionName:{
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
  },
  skillsFrontEnd:{
    error: "",
    validate: "text",
    minLength: 3,
    maxLength: 20
  },
  contact: {
    error: "",
    validate: "phone",
    maxLength: 10
  }
}

const StepForm = () => {
  const [activeStep, setActiveStep] = useState(0)
  const [formValues, setFormValues] = useState(initialValues)
  const [formErrors, setFormErrors] = useState({})

  // Proceed to next step
  const handleNext = () => setActiveStep(prev => prev + 1)
  // Go back to prev step
  const handleBack = () => setActiveStep(prev => prev - 1)

  // Handle form change
  const handleChange = e => {
    const { name, value } = e.target

    // Set values
    setFormValues(prev => ({
      ...prev,
      [name]: value
    }))

    // set errors
    const error = formValidation(name, value, fieldsValidation) || ""

    setFormErrors({
      [name]: error
    })
  }

  const handleSteps = step => {
    switch (step) {
      case 0:
        return (
          <FirstStep handleNext={handleNext}  handleChange={handleChange} values={formValues} formErrors={formErrors} />
        )
      case 1:
        return (
          <SecondStep
            handleNext={handleNext}
            handleBack={handleBack}
            handleChange={handleChange}
            values={formValues}
            formErrors={formErrors}
          />
        )
      case 2:
        return (
          <ThirdStep
            handleNext={handleNext}
            handleBack={handleBack}
            handleChange={handleChange}
            values={formValues}
            formErrors={formErrors}
          />
        ) 
        case 3:
          return (
            <FourthStep
              handleNext={handleNext}
              handleBack={handleBack}
              handleChange={handleChange}
              values={formValues}
              formErrors={formErrors}
            />
          )
          case 4:
            return (
              <FifthStep
                handleNext={handleNext}
                handleBack={handleBack}
                handleChange={handleChange}
                values={formValues}
                formErrors={formErrors}
              />
            )
            case 5:
          return <Confirm handleNext={handleNext} handleBack={handleBack} values={formValues} />
      default:
        break
    }
  }

  return (
    <>
      {activeStep === labels.length ? (
        // Last Component
        <Success values={formValues} />
      ) : (
        <>
          <Box style={{ margin: "10px 200 50px" }}>
            <Typography variant="h4" align="center">
              
            </Typography>
            
          </Box>
          {/* <Stepper activeStep={activeStep} style={{ margin: "30px 0 15px" }} alternativeLabel>
            {labels.map(label => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper> */}
        
          {handleSteps(activeStep)}
        </>
      )}
    </>
  )
}

export default StepForm