import Paper from '@material-ui/core/Paper';
import React from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

export default function TabsComFifth() {
  const [value, setValue] = React.useState(1);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (

      <Tabs
      style={{marginLeft:"350px",marginTop:"20px"}}
        value={value}
        indicatorColor="dark"
        onChange={handleChange}
        aria-label="disabled tabs example"
      >
        <Tab style={{color: "#23cc7c",fontWeight:"bolder", textDecoration: "underline",textDecorationColor:"#23cc7c" }}label="Personal" disabled />
        <Tab label="Educational" style={{color: "#23cc7c",fontWeight:"bolder", textDecoration: "underline",textDecorationColor:"#23cc7c" }} disabled />
        <Tab label="Technology" style={{color: "#23cc7c",fontWeight:"bolder", textDecoration: "underline",textDecorationColor:"#23cc7c" }}  disabled />
        <Tab label="Experience" style={{color: "#23cc7c",fontWeight:"bolder", textDecoration: "underline",textDecorationColor:"#23cc7c" }}  disabled />
        <Tab label="Project Details"  style={{color:'black',fontWeight:"bolder",textDecoration: "underline",textDecorationColor: "Black"}} />
      
      </Tabs>
  
  );
}