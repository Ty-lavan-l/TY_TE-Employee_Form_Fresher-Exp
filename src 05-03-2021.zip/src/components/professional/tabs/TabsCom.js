import Paper from '@material-ui/core/Paper';
import React from 'react';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

export default function TabsCom() {
  const [value, setValue] = React.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (

      <Tabs
      style={{marginLeft:"250px",marginTop:"20px"}}
        value={value}
        indicatorColor="dark"
        onChange={handleChange}
        aria-label="disabled tabs example"
      >
        <Tab style={{color:'black',fontWeight:"bolder", textDecoration: "underline",textDecorationColor: "Black" }}label="Personal" />
        <Tab label="Educational" style={{textDecoration: "underline",textDecorationColor: "Black"}} disabled />
        <Tab label="Technology" style={{textDecoration: "underline",textDecorationColor: "Black"}}  disabled/>
        <Tab label="Experience" style={{color: "Black", textDecoration: "underline",textDecorationColor:"Black" }}  disabled />
        <Tab label="Project Details" style={{textDecoration: "underline",textDecorationColor: "Black"}}  disabled/>
      
      </Tabs>
  
  );
}
