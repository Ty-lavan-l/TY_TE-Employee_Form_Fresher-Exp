import React, { Fragment } from "react"
import List from "@material-ui/core/List"
import ListItem from "@material-ui/core/ListItem"
import ListItemText from "@material-ui/core/ListItemText"
import Divider from "@material-ui/core/Divider"
import Button from "@material-ui/core/Button"

// Destructure props
const Confirm = ({ handleNext, handleBack, values }) => {
  const {emplopyeeId,fullName,contact,doj,emergencyContactOne,emergencyContactTwo,alternateContact,
  offEmail,personalEmail,gender,permanentAddress,
  temporaryAddress,
  resume,
  highestQualification,
  specification,
  institutionName,yop, percentage, skillsFrontEnd,skillsBackEnd,dataBase,delevepomentTools,
  projectName,
  technologyUsed,
  projectSummary,
  roleAndsResponsibility,
 } = values

  const handleSubmit = () => {
    // Do whatever with the values
    console.log(values)
    // Show last compinent or success message
    handleNext()
  }

  return (
    <Fragment>
      <List disablePadding>
        <ListItem>
          <ListItemText primary="Full Name" secondary={fullName} />
        </ListItem>
        <ListItem>
          <ListItemText primary="Employee Id" secondary={emplopyeeId} />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Temporary Address" secondary={temporaryAddress} />
        </ListItem>
        <Divider />
        <ListItem>
          <ListItemText primary="Full Name" secondary={fullName} />
        </ListItem>
        
        <Divider />
        <ListItem>
          <ListItemText primary="Full Name" secondary={fullName} />
        </ListItem>

        <Divider />

        {/* <ListItem>
          <ListItemText primary="Last Name" secondary={lastName} />
        </ListItem>

        <Divider /> */}

        <ListItem>
          <ListItemText primary="Official Email " secondary={offEmail} />
        </ListItem>
        <Divider />
        
        <ListItem>
          <ListItemText primary="Personal Email " secondary={personalEmail} />
        </ListItem>
        <Divider />

        <ListItem>
          <ListItemText primary="Gender" secondary={gender} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="Date of Joining" secondary={doj} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="Permanent Address" secondary={permanentAddress} />
        </ListItem>

        <Divider />

        <ListItem>
          <ListItemText primary="Contact" secondary={contact.length > 0 ? contact : "Not Provided"} />
        </ListItem>
      </List>

      <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
            <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
              {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
            <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
              {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
          </div>
    </Fragment>
  )
}

export default Confirm