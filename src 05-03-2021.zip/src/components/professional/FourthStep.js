import React, { useState } from 'react';
import Container from '@material-ui/core/Container';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button'
import IconButton from '@material-ui/core/IconButton';
import RemoveIcon from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
import { v4 as uuidv4 } from 'uuid';
import { makeStyles } from '@material-ui/core/styles';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Grid from "@material-ui/core/Grid"
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import TabsComFour from './tabs/TabsComFour'


const useStyles = makeStyles((theme) => ({
  root: {
    '& .MuiTextField-root': {
      margin: theme.spacing(1),
    },
  },
  button: {
    margin: theme.spacing(1),
  }
}))

export default function FourthStep({ handleNext, handleBack,company,designation}) {
  
  const classes = useStyles()
  const [inputFields, setInputFields] = useState([
    { id: uuidv4(), company: '', noticeperiod: '', designation: '',city: '',year:'',month:'',Present:'' },
  ]);
  const [state, setState] = React.useState({
    designation: '',
    company: '',
    city:'',
    noticeperiod:'',
    


    
  });
  const handleChange1 = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("InputFields", inputFields);
  };

  const handleChangeInput = (id, event) => {
    const newInputFields = inputFields.map(i => {
      if(id === i.id) {
        i[event.target.name] = event.target.value
      }
      return i;
    })
    
    setInputFields(newInputFields);
  }

  const handleAddFields = () => {
    setInputFields([...inputFields, { id: uuidv4(),  designation: '', company: '', InstitutionName: '',years: '',Present:'',month:'',city:'' }])
  }

  const handleRemoveFields = id => {
    const values  = [...inputFields];
    values.splice(values.findIndex(value => value.id === id), 1);
    setInputFields(values);
  }

  return (
    <>
    <TabsComFour/>
    <Grid container spacing={2} alignItems="center">
    <Grid xs={3}>
        </Grid>
      <Grid item xs={6} fullWidth style={{marginTop:"50px"}}>
      

      <form className={classes.root} onSubmit={handleSubmit}>
        { inputFields.map(inputField => (
          <div key={inputField.id}>

<Grid item xs={12} fullWidth>
          <TextField
          
            fullWidth
            label="Designation"
            name="designation"
            placeholder="designation"
            margin="normal"
            value={state.designation}
            onChange={handleChange1}
           
           helperText={designation}
            
            
            variant="outlined"
          />
        </Grid>
        <Grid item xs={12} fullWidth>
          <TextField
          
            fullWidth
            label="company"
            name="company"
            placeholder="Company"
            margin="normal"
            value={state.Company}
            onChange={handleChange1}
           
           helperText={company}
            
            
            variant="outlined"
          />
        </Grid>
        &ensp; 
        {/* <Grid style={{display:"flex"}} item xs={3} > */}

         
         <b> Working Since :</b>
         &emsp;
               
               
      <FormControl variant="outlined" className={classes.formControl} xs={12} >
        <InputLabel htmlFor="outlined-age-native-simple">Year</InputLabel>
        <Select
          native
          value={state.year}
          onChange={handleChange1}
          
          label="year" 
          inputProps={{
            name:'year',
            id: 'outlined-age-native-simple',
          }}
        >
          <option aria-label="None" value="" />
          <option value={10}>2015</option>
          <option value={20}>2016</option>
          <option value={30}>2017</option>
          <option value={40}>2018</option>
          <option value={50}>2019</option>
          <option value={60}>2020</option>
          <option value={70}>2021</option>
        </Select>
      </FormControl>
      &emsp;
      &emsp;
               
               
               
      <FormControl variant="outlined" className={classes.formControl} sm={3}>
        <InputLabel htmlFor="outlined-age-native-simple">Month  </InputLabel>
        <Select
          native
          value={state.month}
          onChange={handleChange1}
          label="month"
          inputProps={{
            name: 'month',
            id: 'outlined-age-native-simple',
          }}
        >
          <option aria-label="None" value="" />
          <option value={10}>Jan</option>
          <option value={20}>Feb</option>
          <option value={30}>Mar</option>
          <option value={40}>Apr</option>
          <option value={50}>May</option>
          <option value={60}>Jun</option>
          <option value={70}>Jul</option>
          <option value={80}>Aug</option>
          <option value={90}>Sept</option>
          <option value={110}>Oct</option>
          <option value={120}>Nov</option>
          <option value={130}>Dec</option>
        </Select>
      </FormControl>
      &emsp;
      &emsp;
               
               
     <b>  To : </b>
     &emsp;
               
      <TextField
        id="datetime-local"
        label="Present"
        type="datetime-local"
        defaultValue="2017-05-24T10:30"
        className={classes.textField}
        variant="outlined"
        InputLabelProps={{
          shrink: true,
        }}
      />
      {/* </Grid> */}

      
            <Autocomplete
        
        name="city"
        freeSolo
        options={city.map((option) => option.title)}
        renderInput={(params) => (
          <TextField {...params} label="City" margin="normal" variant="outlined" />
         
        )}
        value={inputField.qualification}
        onChange={event => handleChangeInput(inputField.id, event)}
      />
          
        <Autocomplete
        
        name="noticeperiod"
        freeSolo
        options={noticeperiod.map((option) => option.title)}
        renderInput={(params) => (
          <TextField {...params} label="Duration of Notice Period" margin="normal" variant="outlined" />
         
        )}
        value={inputField.qualification}
        onChange={event => handleChangeInput(inputField.id, event)}
      />
              
          <div  style={{display:"flex",justifyContent:"flex-end"}}>
            <IconButton disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>
              <RemoveIcon />
            </IconButton>
            <IconButton
              onClick={handleAddFields}
            >
              <AddIcon />
            </IconButton>
            </div>
            {/* <Button disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)} >Remove</Button>
            <Button onClick={handleAddFields}>+Add More Education</Button> */}
          </div>
        )) }
       
        
      </form>
     
      <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
            <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
              {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
            <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
              {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
          </div>
      </Grid>
   </Grid>
    </>
  );
}
const city = [
  { title: 'Bangalore' },
  { title: 'Delhi' },
  { title: 'Chennai'},
  { title: 'Mumbai' },
  { title: 'Hyderabad' },
  { title: "Jaipur" },
  { title: "Pune" },
  { title: 'Vijayawada'},
  { title: 'Jabalpur' },
  { title: 'Mysuru' },
  { title: "Mangalore" },
  { title: "Kolkata" },
  
];
const noticeperiod = [
  { title: '1month' },
  { title: '2months' },
  { title: '3months'},
  
];