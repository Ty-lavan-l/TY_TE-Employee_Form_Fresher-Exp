import React ,{useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import OutlinedInput from '@material-ui/core/OutlinedInput';
import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import TextField from '@material-ui/core/TextField';
import Grid from "@material-ui/core/Grid"
import TabsComFour from './tabs/TabsComFour'
import Button from "@material-ui/core/Button"
import Container from '@material-ui/core/Container';
import IconButton from '@material-ui/core/IconButton';
import RemoveIcon from '@material-ui/icons/Remove';
import AddIcon from '@material-ui/icons/Add';
import { v4 as uuidv4 } from 'uuid';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import TabsComFifth from './tabs/TabsComFifth';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    flexGrow: 1,
  },
  margin: {
    margin: theme.spacing(1),
  },
  withoutLabel: {
    marginTop: theme.spacing(3),
  },
  textField: {
    width: '1200px'

  },
}));

export default function FifthStep({ handleNext,handleBack, values: { pname,roles,techused,psummary }, formErrors }) {
  const classes = useStyles();
  const isValid =
  pname!= null && !formErrors. pname &&
  techused != null && !formErrors. techused && psummary != null && !formErrors. psummary
    && roles != null && !formErrors.roles
  const [values, setValues] = React.useState({
    pname: '',
    techused: '',
    psummary: '',
    roles:'',

  });

  const [inputFields, setInputFields] = useState([
    { id: uuidv4(), projectdetails: '', technology: '', projectsum: '',randr:'' },
  ]);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("InputFields", inputFields);
  };

  const handleChangeInput = (id, event) => {
    const newInputFields = inputFields.map(i => {
      if(id === i.id) {
        i[event.target.name] = event.target.value
      }
      return i;
    })
    
    setInputFields(newInputFields);
  }

  const handleAddFields = () => {
    setInputFields([...inputFields, { id: uuidv4(),  projectdetails: '', technology: '', projectsum: '',randr:''  }])
  }

  const handleRemoveFields = id => {
    const values  = [...inputFields];
    values.splice(values.findIndex(value => value.id === id), 1);
    setInputFields(values);
  }

  return (
      <div>
        <TabsComFifth />
          <Grid  item xs={12} sm={9} alignItems="center" style={{marginTop:"50px", marginLeft:'150px'}}>
                    <Grid item xs={3}></Grid>    

        
    <Grid  >

      <form  onSubmit={handleSubmit}>
        { inputFields.map(inputField => (
          <div key={inputField.id}>
            <Grid   direction="row"
              justify="center"
              alignItems="center"
            >
              <FormControl fullWidth className={classes.margin} variant="outlined" xs={12}>
                <InputLabel htmlFor="outlined-adornment-amount"></InputLabel>
                <OutlinedInput
                  id="outlined-adornment-amount"
                  placeholder="Project Name"
                  name="pname"
                  fullWidth
                  startAdornment={<InputAdornment position="start"></InputAdornment>}

                />
              </FormControl>
              </Grid>
            <br/>
            <Grid>
              <FormControl fullWidth className={classes.margin} variant="outlined">
                <InputLabel htmlFor="outlined-adornment-amount"></InputLabel>
                <OutlinedInput
                  id="outlined-adornment-amount"
                  placeholder="Technology Used : "

                  name="techused"
                  startAdornment={<InputAdornment position="start"></InputAdornment>}
                 
                />
              </FormControl>
            </Grid>
            <br/>
        <Grid>
        <div style={{display:'flex'}}>
              <TextField
                id="outlined-multiline-static"
                name="psummary"
                multiline
                fullWidth
                rows={8}
                label="Project Summary :"
                variant="outlined"
              />
            </div>
        </Grid>
        <br/>
        <Grid>
        <div >
              <TextField
                id="outlined-multiline-static"
                name="psummary"
                multiline
                fullWidth
                rows={8}
                label="Roles & Responsibility"
                variant="outlined"
              />
            </div>
        </Grid>
        <br/>
        <div style={{display:'flex', justifyContent:'flex-end'}}>
            <IconButton disabled={inputFields.length === 1} onClick={() => handleRemoveFields(inputField.id)}>
              <RemoveIcon />
            </IconButton>
            <IconButton
              onClick={handleAddFields}
            >
              <AddIcon />
            </IconButton>
            </div>
           
            </div>
            
        )) }
        <Grid>
        <div style={{ display: "flex", marginTop: 50, justifyContent: "flex-end" }}>
            <Button variant="contained" color="default" onClick={handleBack} style={{ marginRight: 10 ,backgroundColor:"#23cc7c", color:'white',width:"100px"}} >
              {/* onClick={handleBack} style={{ marginRight: 10 }} */}
          Back
        </Button>
            <Button variant="contained" color="primary" onClick={handleNext} style={{ backgroundColor:"#23cc7c", color:'white',width:"200px"}} >
              {/* disabled={!isValid} color="primary" onClick={isValid ? handleNext : null} */}
         Next
      </Button>
          </div>
        </Grid>
        
            </form>
            </Grid>
          </Grid>
            </div>

            
          
  );
}
